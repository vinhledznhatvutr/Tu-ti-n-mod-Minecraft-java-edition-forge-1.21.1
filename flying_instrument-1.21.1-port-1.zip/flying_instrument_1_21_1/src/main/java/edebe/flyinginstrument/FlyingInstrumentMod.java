package edebe.flyinginstrument;

import edebe.flyinginstrument.registry.ModCreativeTabs;
import edebe.flyinginstrument.registry.ModEntities;
import edebe.flyinginstrument.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(FlyingInstrumentMod.MODID)
public class FlyingInstrumentMod {
    public static final String MODID = "flyinginstrument";
    public static final String NAME = "Flying Instrument";

    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    public FlyingInstrumentMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.register(modEventBus);
        ModEntities.register(modEventBus);
        ModCreativeTabs.register(modEventBus);

        // edebe.flyinginstrument.registry.ModAttributes and edebe.flyinginstrument.event.EventHandler
        // register themselves via @Mod.EventBusSubscriber.
        // edebe.flyinginstrument.client.ClientModEvents registers itself the same way, restricted
        // to the client physical side (renderers + key mapping).
    }
}
