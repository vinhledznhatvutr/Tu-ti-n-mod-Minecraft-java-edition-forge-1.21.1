package edebe.flyinginstrument.client;

import edebe.flyinginstrument.FlyingInstrumentMod;
import edebe.flyinginstrument.key.ModKeyMappings;
import edebe.flyinginstrument.registry.ModEntities;
import edebe.flyinginstrument.render.RenderFlySword;
import edebe.flyinginstrument.render.RenderFlyingInstrument;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FlyingInstrumentMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FLYING_INSTRUMENT.get(), RenderFlyingInstrument::new);
        event.registerEntityRenderer(ModEntities.FLY_SWORD.get(), RenderFlySword::new);
    }

    @SubscribeEvent
    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(ModKeyMappings.FLYING_INSTRUMENT_DOWN);
    }
}
