package edebe.flyinginstrument.entity;

import edebe.flyinginstrument.item.IFlyingInstrumentItem;
import edebe.flyinginstrument.key.ModKeyMappings;
import net.minecraft.client.Minecraft;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

/**
 * Ported from EntityFlySword (1.12.2). Functionally identical to EntityFlyingInstrument;
 * kept as a separate class (rather than merged) to mirror the original mod's structure,
 * since ItemFlySword.createEntity() specifically returns this type.
 */
public class EntityFlySword extends Mob implements IFlyingInstrumentEntity {
    private static final String NBT_KEY_ITEMSTACK = "ItemStack";
    private static final String NBT_KEY_OWNER_UUID = "OwnerUniqueID";

    private static final EntityDataAccessor<ItemStack> SWORD_ITEM_STACK = SynchedEntityData.defineId(EntityFlySword.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Byte> CONTROL_STATE = SynchedEntityData.defineId(EntityFlySword.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Optional<UUID>> OWNER_UNIQUE_ID = SynchedEntityData.defineId(EntityFlySword.class, EntityDataSerializers.OPTIONAL_UUID);

    protected double mountedYOffset;
    protected boolean shouldRiderSit;

    public EntityFlySword(EntityType<? extends EntityFlySword> type, Level level) {
        super(type, level);
        this.setInvulnerable(true);
    }

    public EntityFlySword(Level level, ItemStack stack, Player player) {
        this(edebe.flyinginstrument.registry.ModEntities.FLY_SWORD.get(), level);
        this.setItemStack(stack);
        this.setOwnerID(player.getUUID());
        this.setPos(player.getX(), player.getY(), player.getZ());
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 6.0D);
    }

    @Override
    protected void registerGoals() {
        // No AI: this entity is purely a player-driven mount.
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SWORD_ITEM_STACK, ItemStack.EMPTY);
        builder.define(CONTROL_STATE, (byte) 0);
        builder.define(OWNER_UNIQUE_ID, Optional.empty());
    }

    @Override
    public void readAdditionalSaveData(@Nonnull CompoundTag compound) {
        super.readAdditionalSaveData(compound);
        if (compound.contains(NBT_KEY_ITEMSTACK, 10)) {
            HolderLookup.Provider provider = this.registryAccess();
            this.setItemStack(ItemStack.parseOptional(provider, compound.getCompound(NBT_KEY_ITEMSTACK)));
        }
        if (compound.hasUUID(NBT_KEY_OWNER_UUID)) this.setOwnerID(compound.getUUID(NBT_KEY_OWNER_UUID));
    }

    @Override
    public void addAdditionalSaveData(@Nonnull CompoundTag compound) {
        super.addAdditionalSaveData(compound);
        if (!this.getItemStack().isEmpty()) {
            CompoundTag itemTag = new CompoundTag();
            this.getItemStack().save(this.registryAccess(), itemTag);
            compound.put(NBT_KEY_ITEMSTACK, itemTag);
        }
        if (this.getOwnerID() != null) compound.putUUID(NBT_KEY_OWNER_UUID, this.getOwnerID());
    }

    public double getMountedYOffset() {
        return this.mountedYOffset;
    }

    public boolean shouldRiderSit() {
        return this.shouldRiderSit;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        net.minecraft.world.entity.Entity first = this.getFirstPassenger();
        return first instanceof LivingEntity livingEntity ? livingEntity : null;
    }

    @Override
    protected void positionRider(@Nonnull net.minecraft.world.entity.Entity passenger, @Nonnull MoveFunction moveFunction) {
        if (this.hasPassenger(passenger)) {
            moveFunction.accept(passenger, this.getX(), this.getY() + this.getMountedYOffset(), this.getZ());
            if (passenger instanceof LivingEntity livingEntity) {
                livingEntity.stopRiding();
            }
        }
    }

    @Override
    protected void removePassenger(@Nonnull net.minecraft.world.entity.Entity entity) {
        super.removePassenger(entity);
        if (entity.getUUID().equals(this.getOwnerID()) && entity instanceof Player player) this.putAwaySword(player);
    }

    @Override
    public boolean causeFallDamage(float distance, float damageMultiplier, @Nonnull DamageSource source) {
        return false;
    }

    @Override
    public boolean hurt(@Nonnull DamageSource source, float amount) {
        Player controllingPlayer = this.getControllingPlayer();
        if (controllingPlayer != null || source.getEntity() == null) return false;
        if (this.isOwner(source.getEntity()) && source.getEntity() instanceof Player player) this.putAwaySword(player);
        return false;
    }

    @Override
    public void tick() {
        this.xxa *= 0.98F;
        this.zza *= 0.98F;

        Item item = this.getItemStack().getItem();
        if (item instanceof IFlyingInstrumentItem flyingInstrument) {
            this.mountedYOffset = flyingInstrument.getMountedYOffset();
            this.maxUpStep = flyingInstrument.getStepHeight();
            this.shouldRiderSit = flyingInstrument.shouldRiderSit();
        }

        Player player = this.getControllingPlayer();
        if (!this.level().isClientSide && player != null && player.isShiftKeyDown()) {
            this.putAwaySword(player);
            return;
        }
        if (!this.level().isClientSide && player == null) {
            this.discard();
            return;
        }

        super.tick();
        if (this.level().isClientSide) this.updateClientControls();

        if (player != null) {
            CompoundTag data = player.getPersistentData();
            if (data.contains("Power") && data.getDouble("Power") > 0) {
                if (this.getItemStack().getItem() instanceof IFlyingInstrumentItem) {
                    data.putBoolean("FaQiFly", true);
                    if (data.contains("JingJieNum")) {
                        data.putDouble("FlySowrdTime", data.getDouble("FlySowrdTime") + 1);
                        if (data.getDouble("FlySowrdTime") >= 20) {
                            data.putDouble("FlySowrdTime", 0);
                            if (data.getDouble("JingJieNum") >= 1 && data.getDouble("JingJieNum") <= 2)
                                data.putDouble("Power", data.getDouble("Power") - 3);
                            else data.putDouble("Power", data.getDouble("Power") - 6);
                        }
                    }
                }
            } else {
                data.putBoolean("FaQiFly", false);
                this.putAwaySword(player);
            }
        }
    }

    @Override
    protected void playStepSound(@Nonnull net.minecraft.core.BlockPos pos, @Nonnull net.minecraft.world.level.block.state.BlockState state) {
        // Silent while ridden - matches the original mod's behavior.
    }

    @Override
    public void travel(@Nonnull Vec3 relative) {
        Player player = this.getControllingPlayer();
        if (this.isVehicle() && player != null) {
            if (this.down()) this.setDeltaMovement(this.getDeltaMovement().add(0, -0.03F, 0));
            if (this.up()) this.setDeltaMovement(this.getDeltaMovement().add(0, 0.03F, 0));

            this.setYRot(player.getYRot());
            this.yRotO = this.getYRot();
            this.setXRot(player.getXRot() * 0.5F);
            this.setRot(this.getYRot(), this.getXRot());
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.yBodyRot;

            float strafe = player.xxa * 0.5F;
            float forward = player.zza;
            if (forward <= 0.0F) forward *= 0.25F;

            this.flyingSpeed = this.getSpeed() * 0.1F;

            if (this.canBeControlledByRider()) {
                this.setSpeed((float) this.getAttributeValue(Attributes.MOVEMENT_SPEED));
                this.doTravel(strafe, relative.y, forward);
            } else {
                this.setDeltaMovement(Vec3.ZERO);
            }

            this.calculateEntityAnimation(false);
        } else {
            this.setDeltaMovement(Vec3.ZERO);
            this.flyingSpeed = 0.02F;
            this.doTravel((float) relative.x, (float) relative.y, (float) relative.z);
        }
    }

    private void doTravel(float strafe, float vertical, float forward) {
        this.moveRelative(this.flyingSpeed, new Vec3(strafe, vertical, forward));
        this.move(MoverType.SELF, this.getDeltaMovement());
    }

    @Override
    public EntityDimensions getDimensions(@Nonnull Pose pose) {
        Item item = this.getItemStack().getItem();
        if (item instanceof IFlyingInstrumentItem flyingInstrument) {
            return EntityDimensions.scalable(flyingInstrument.getWidth(), flyingInstrument.getHeight());
        }
        return super.getDimensions(pose);
    }

    protected void setItemStack(ItemStack itemStack) {
        this.entityData.set(SWORD_ITEM_STACK, itemStack);
        this.refreshDimensions();
    }

    public ItemStack getItemStack() {
        return this.entityData.get(SWORD_ITEM_STACK);
    }

    public UUID getOwnerID() {
        return this.entityData.get(OWNER_UNIQUE_ID).orElse(null);
    }

    protected void setOwnerID(@Nullable UUID uniqueID) {
        this.entityData.set(OWNER_UNIQUE_ID, Optional.ofNullable(uniqueID));
    }

    public Player getOwner() {
        try {
            UUID uuid = this.getOwnerID();
            return uuid == null ? null : this.level().getPlayerByUUID(uuid);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public boolean isOwner(net.minecraft.world.entity.Entity entity) {
        return entity instanceof Player && entity == this.getOwner();
    }

    public Player getControllingPlayer() {
        net.minecraft.world.entity.Entity entity = this.getControllingPassenger();
        return entity instanceof Player ? (Player) entity : null;
    }

    @Override
    public void putAwaySword(Player player) {
        if (!this.level().isClientSide) {
            ItemStack sword = this.getItemStack();
            if (!player.getInventory().add(sword)) this.spawnAtLocation(sword);
        }
        this.discard();
    }

    @OnlyIn(Dist.CLIENT)
    protected void updateClientControls() {
        Minecraft minecraft = Minecraft.getInstance();
        if (this.isRidingPlayer(minecraft.player)) {
            this.up(minecraft.options.keyJump.isDown());
            this.down(ModKeyMappings.FLYING_INSTRUMENT_DOWN.isDown());
        }
    }

    private boolean up() {
        return (this.entityData.get(CONTROL_STATE) & 1) == 1;
    }

    private boolean down() {
        return (this.entityData.get(CONTROL_STATE) >> 1 & 1) == 1;
    }

    private void up(boolean up) {
        this.setStateField(0, up);
    }

    private void down(boolean down) {
        this.setStateField(1, down);
    }

    private void setStateField(int i, boolean newState) {
        byte prevState = this.entityData.get(CONTROL_STATE);
        if (newState) this.entityData.set(CONTROL_STATE, (byte) (prevState | (1 << i)));
        else this.entityData.set(CONTROL_STATE, (byte) (prevState & ~(1 << i)));
    }

    private boolean isRidingPlayer(Player player) {
        return this.isVehicle() && this.getControllingPassenger() == player;
    }

    @Override
    public boolean showVehicleHealth() {
        return false;
    }
}
