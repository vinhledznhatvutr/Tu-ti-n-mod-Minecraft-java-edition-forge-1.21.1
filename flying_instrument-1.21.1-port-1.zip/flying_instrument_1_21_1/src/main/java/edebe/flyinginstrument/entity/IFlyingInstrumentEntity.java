package edebe.flyinginstrument.entity;

import net.minecraft.world.entity.player.Player;

public interface IFlyingInstrumentEntity {
    void putAwaySword(Player player);
}
