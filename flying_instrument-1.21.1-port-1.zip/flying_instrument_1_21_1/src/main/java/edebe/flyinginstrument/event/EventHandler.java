package edebe.flyinginstrument.event;

import edebe.flyinginstrument.FlyingInstrumentMod;
import edebe.flyinginstrument.entity.IFlyingInstrumentEntity;
import edebe.flyinginstrument.item.IFlyingInstrumentItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.AttackEntityEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FlyingInstrumentMod.MODID)
public class EventHandler {

    @SubscribeEvent
    public static void onPlayerRightClickItem(PlayerInteractEvent.RightClickItem event) {
        Level level = event.getLevel();
        if (!level.isClientSide) {
            Player player = event.getEntity();
            ItemStack stack = event.getItemStack();
            CompoundTag data = player.getPersistentData();
            if (data.contains("Power") && data.getFloat("Power") > 0 && !player.isPassenger() && stack.getItem() instanceof IFlyingInstrumentItem) {
                if (level instanceof ServerLevel serverLevel) {
                    stack.hurtAndBreak(1, serverLevel, player, item -> {});
                }
                if (!player.isShiftKeyDown()) {
                    IFlyingInstrumentItem flyingInstrumentItem = (IFlyingInstrumentItem) stack.getItem();
                    Entity mount = flyingInstrumentItem.createEntity(level, stack.copy(), player);
                    mount.setPos(player.getX(), player.getY(), player.getZ());
                    level.addFreshEntity(mount);
                    event.getEntity().startRiding(mount);
                    stack.shrink(1);
                }
            } else if (stack.getItem() instanceof IFlyingInstrumentItem && data.contains("Power") && data.getFloat("Power") <= 0) {
                player.sendSystemMessage(Component.translatable("message.flyinginstrument.use.flysword.fail"));
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerUpdate(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = event.player;
        if (player.isPassenger() && player.isShiftKeyDown()) {
            Entity riding = player.getVehicle();
            if (riding instanceof IFlyingInstrumentEntity flyingInstrumentEntity) {
                flyingInstrumentEntity.putAwaySword(player);
                player.stopRiding();
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerLoggedOutEvent(PlayerEvent.PlayerLoggedOutEvent event) {
        Player player = event.getEntity();
        if (player != null && !player.level().isClientSide) {
            if (player.isPassenger()) {
                Entity riding = player.getVehicle();
                if (riding instanceof IFlyingInstrumentEntity flyingInstrumentEntity) {
                    flyingInstrumentEntity.putAwaySword(player);
                    player.stopRiding();
                }
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerAttackEntityEvent(AttackEntityEvent event) {
        Player player = event.getEntity();
        if (player != null && !player.level().isClientSide) {
            ItemStack itemStack = player.getItemBySlot(EquipmentSlot.MAINHAND);
            if (!itemStack.isEmpty() && itemStack.getItem() instanceof IFlyingInstrumentItem) {
                event.setCanceled(true);
            }
        }
    }
}
