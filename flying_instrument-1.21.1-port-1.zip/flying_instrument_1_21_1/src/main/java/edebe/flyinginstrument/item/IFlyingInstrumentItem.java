package edebe.flyinginstrument.item;

import edebe.flyinginstrument.entity.IFlyingInstrumentEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public interface IFlyingInstrumentItem {
    float getWidth();

    float getHeight();

    double getMountedYOffset();

    float getStepHeight();

    boolean shouldRiderSit();

    <T extends IFlyingInstrumentEntity> T createEntity(Level level, ItemStack stack, Player player);
}
