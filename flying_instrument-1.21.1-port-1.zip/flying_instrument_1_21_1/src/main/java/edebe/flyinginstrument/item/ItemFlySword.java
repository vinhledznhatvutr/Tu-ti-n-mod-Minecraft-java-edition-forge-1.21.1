package edebe.flyinginstrument.item;

import edebe.flyinginstrument.entity.EntityFlySword;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ItemFlySword extends Item implements IFlyingInstrumentItem {

    public ItemFlySword(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        return true;
    }

    @Override
    public float getWidth() {
        return 3F;
    }

    @Override
    public float getHeight() {
        return 0.2F;
    }

    @Override
    public double getMountedYOffset() {
        return 0.5;
    }

    @Override
    public float getStepHeight() {
        return 0.2F;
    }

    @Override
    public boolean shouldRiderSit() {
        return false;
    }

    @Override
    public EntityFlySword createEntity(Level level, ItemStack stack, Player player) {
        return new EntityFlySword(level, stack, player);
    }
}
