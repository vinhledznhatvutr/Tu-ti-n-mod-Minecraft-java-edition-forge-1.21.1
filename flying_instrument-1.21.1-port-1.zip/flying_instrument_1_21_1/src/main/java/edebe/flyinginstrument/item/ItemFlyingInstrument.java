package edebe.flyinginstrument.item;

import edebe.flyinginstrument.entity.EntityFlyingInstrument;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Ported from ItemFlyingInstrument (1.12.2). The original picked width/height/offset
 * by comparing `this` against static fields on a shared item loader class; that created a
 * fragile static-init-order dependency, so here each instance carries its own geometry
 * instead of switching on identity. Behavior for each item is unchanged (see ModItems).
 */
public class ItemFlyingInstrument extends Item implements IFlyingInstrumentItem {
    private final float width;
    private final float height;
    private final double mountedYOffset;
    private final boolean shouldRiderSit;

    public ItemFlyingInstrument(Properties properties, float width, float height, double mountedYOffset, boolean shouldRiderSit) {
        super(properties.stacksTo(1));
        this.width = width;
        this.height = height;
        this.mountedYOffset = mountedYOffset;
        this.shouldRiderSit = shouldRiderSit;
    }

    @Override
    public float getWidth() {
        return this.width;
    }

    @Override
    public float getHeight() {
        return this.height;
    }

    @Override
    public double getMountedYOffset() {
        return this.mountedYOffset;
    }

    @Override
    public float getStepHeight() {
        return 32;
    }

    @Override
    public boolean shouldRiderSit() {
        return this.shouldRiderSit;
    }

    @Override
    public EntityFlyingInstrument createEntity(Level level, ItemStack stack, Player player) {
        return new EntityFlyingInstrument(level, stack, player);
    }
}
