package edebe.flyinginstrument.key;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ModKeyMappings {
    public static final KeyMapping FLYING_INSTRUMENT_DOWN = new KeyMapping(
            "key.flyinginstrument.down",
            InputConstants.Type.KEYSYM,
            InputConstants.KEY_X,
            "key.categories.flyinginstrument");
}
