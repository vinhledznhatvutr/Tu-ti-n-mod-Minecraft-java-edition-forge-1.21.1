package edebe.flyinginstrument.registry;

import edebe.flyinginstrument.FlyingInstrumentMod;
import edebe.flyinginstrument.entity.EntityFlySword;
import edebe.flyinginstrument.entity.EntityFlyingInstrument;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FlyingInstrumentMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModAttributes {
    @SubscribeEvent
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(ModEntities.FLYING_INSTRUMENT.get(), EntityFlyingInstrument.createAttributes().build());
        event.put(ModEntities.FLY_SWORD.get(), EntityFlySword.createAttributes().build());
    }
}
