package edebe.flyinginstrument.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import static edebe.flyinginstrument.FlyingInstrumentMod.MODID;

/**
 * NOTE: the original 1.12.2 source pulled its creative tab from a companion mod
 * ("net.mcreator.fabaokuozhan.creativetab.TabLianqi") that was not included in the
 * uploaded project, so this tab is a self-contained replacement with the same name/feel.
 */
public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<CreativeModeTab> FLYING_INSTRUMENT_TAB = CREATIVE_MODE_TABS.register("tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.flyinginstrument.tab"))
                    .icon(() -> ModItems.GOURD.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.GOLD_SWORD.get());
                        output.accept(ModItems.WOOD_SWORD.get());
                        output.accept(ModItems.WATER_SWORD.get());
                        output.accept(ModItems.FIRE_SWORD.get());
                        output.accept(ModItems.SOIL_SWORD.get());
                        output.accept(ModItems.BLUE_POINT_SWORD.get());
                        output.accept(ModItems.LEAF.get());
                        output.accept(ModItems.GOURD.get());
                        output.accept(ModItems.BOAT.get());
                        output.accept(ModItems.MOUNTAIN_AND_RIVER_DIAGRAM.get());
                    })
                    .withTabsBefore(CreativeModeTabs.COMBAT)
                    .build());

    public static void register(IEventBus modEventBus) {
        CREATIVE_MODE_TABS.register(modEventBus);
    }
}
