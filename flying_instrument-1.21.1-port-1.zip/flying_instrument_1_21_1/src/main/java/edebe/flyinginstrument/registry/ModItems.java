package edebe.flyinginstrument.registry;

import edebe.flyinginstrument.item.ItemFlySword;
import edebe.flyinginstrument.item.ItemFlyingInstrument;
import net.minecraft.world.item.Item;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import static edebe.flyinginstrument.FlyingInstrumentMod.MODID;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Item> GOLD_SWORD = ITEMS.register("gold_sword", () -> new ItemFlySword(new Item.Properties()));
    public static final RegistryObject<Item> WOOD_SWORD = ITEMS.register("wood_sword", () -> new ItemFlySword(new Item.Properties()));
    public static final RegistryObject<Item> WATER_SWORD = ITEMS.register("water_sword", () -> new ItemFlySword(new Item.Properties()));
    public static final RegistryObject<Item> FIRE_SWORD = ITEMS.register("fire_sword", () -> new ItemFlySword(new Item.Properties()));
    public static final RegistryObject<Item> SOIL_SWORD = ITEMS.register("soil_sword", () -> new ItemFlySword(new Item.Properties()));
    public static final RegistryObject<Item> BLUE_POINT_SWORD = ITEMS.register("blue_point_sword", () -> new ItemFlySword(new Item.Properties()));

    // width, height, mountedYOffset, shouldRiderSit - values match the original 1.12.2 ItemFlyingInstrument switch
    public static final RegistryObject<Item> LEAF = ITEMS.register("leaf",
            () -> new ItemFlyingInstrument(new Item.Properties(), 4F, 0.3F, 0.5, false));
    public static final RegistryObject<Item> GOURD = ITEMS.register("gourd",
            () -> new ItemFlyingInstrument(new Item.Properties(), 1.6F, 1.2F, 0.9, true));
    public static final RegistryObject<Item> BOAT = ITEMS.register("boat",
            () -> new ItemFlyingInstrument(new Item.Properties(), 5F, 1.4F, 0.5, false));
    public static final RegistryObject<Item> MOUNTAIN_AND_RIVER_DIAGRAM = ITEMS.register("shan_he_tu",
            () -> new ItemFlyingInstrument(new Item.Properties(), 6F, 0.2F, 0.5, false));

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
    }
}
