package edebe.flyinginstrument.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import edebe.flyinginstrument.entity.EntityFlyingInstrument;
import edebe.flyinginstrument.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nonnull;

public class RenderFlyingInstrument extends EntityRenderer<EntityFlyingInstrument> {
    public RenderFlyingInstrument(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(@Nonnull EntityFlyingInstrument entity, float entityYaw, float partialTicks, @Nonnull PoseStack poseStack, @Nonnull MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        net.minecraft.client.renderer.entity.ItemRenderer mcItemRenderer = Minecraft.getInstance().getItemRenderer();
        ItemStack itemStack = entity.getItemStack();
        Item item = itemStack.getItem();

        if (item == ModItems.GOURD.get()) {
            poseStack.scale(2.0F, 2.0F, 2.0F);
            poseStack.translate(0, 0.55, 0);
            poseStack.mulPose(Axis.XP.rotationDegrees(180));
            poseStack.mulPose(Axis.XP.rotationDegrees(90));
            poseStack.mulPose(Axis.XP.rotationDegrees(-entityYaw + 180));
        } else if (item == ModItems.LEAF.get()) {
            poseStack.scale(2.0F, 2.0F, 2.0F);
            poseStack.translate(0, 0.5, 0);
            poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw + 180));
        } else if (item == ModItems.BOAT.get()) {
            poseStack.scale(2.0F, 2.0F, 2.0F);
            poseStack.translate(0, 0.58, 0);
            poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw + 180));
        } else if (item == ModItems.MOUNTAIN_AND_RIVER_DIAGRAM.get()) {
            poseStack.scale(2.0F, 2.0F, 2.0F);
            poseStack.translate(0, 0.535, 0);
            poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw + 180));
        } else {
            poseStack.translate(0, 1.2, 0);
            poseStack.mulPose(Axis.ZP.rotationDegrees(-45));
            poseStack.mulPose(Axis.XP.rotationDegrees(90));
            poseStack.mulPose(Axis.ZP.rotationDegrees(entityYaw + 90));
        }

        mcItemRenderer.renderStatic(itemStack, ItemDisplayContext.NONE, packedLight, OverlayTexture.NO_OVERLAY, poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Nonnull
    @Override
    public ResourceLocation getTextureLocation(@Nonnull EntityFlyingInstrument entity) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
