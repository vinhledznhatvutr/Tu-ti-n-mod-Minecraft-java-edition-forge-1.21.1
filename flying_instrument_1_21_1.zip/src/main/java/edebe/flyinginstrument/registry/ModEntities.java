package edebe.flyinginstrument.registry;

import edebe.flyinginstrument.entity.EntityFlySword;
import edebe.flyinginstrument.entity.EntityFlyingInstrument;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import static edebe.flyinginstrument.FlyingInstrumentMod.MODID;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);

    public static final RegistryObject<EntityType<EntityFlyingInstrument>> FLYING_INSTRUMENT = ENTITY_TYPES.register("flying_instrument",
            () -> EntityType.Builder.<EntityFlyingInstrument>of(EntityFlyingInstrument::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F)
                    .clientTrackingRange(64)
                    .updateInterval(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(MODID, "flying_instrument"))));

    public static final RegistryObject<EntityType<EntityFlySword>> FLY_SWORD = ENTITY_TYPES.register("fly_sword",
            () -> EntityType.Builder.<EntityFlySword>of(EntityFlySword::new, MobCategory.MISC)
                    .sized(1.0F, 1.0F)
                    .clientTrackingRange(64)
                    .updateInterval(10)
                    .build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(MODID, "fly_sword"))));

    public static void register(IEventBus modEventBus) {
        ENTITY_TYPES.register(modEventBus);
    }
}
